import express from 'express';
import appConfig from '../../../config/app.config.js';

import Repository from '../repositories/media-type.repository.js';
import BaseService from '../../../shared/generic/base.service.js';
import BaseController from '../../../shared/generic/base.controller.js';

import { ITEM_CONSTANTS } from '../constants/media-type.constant.js';
import { validateItem } from '../schemas/media-type.schema.js';

const router = express.Router();

const repository = new Repository(appConfig.app.dbClient);
const service = new BaseService(repository, ITEM_CONSTANTS);
const controller = new BaseController(service, ITEM_CONSTANTS, { validateItem });

router.get('/', controller.getItems);
router.get('/:id', controller.getItemById);
router.post('/', controller.createItem);
router.put('/:id', controller.updateItem);
router.delete('/:id', controller.deleteItem);

export default router;
